/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package electricity.management.system;

import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public interface ReadOnlyBill {
    
    public Bill getBill(int bill_id);
    public ArrayList<Bill> viewBillingHistory(Customer c);
    public ArrayList<Bill> viewUnpaidBills(Customer c);
    
}
