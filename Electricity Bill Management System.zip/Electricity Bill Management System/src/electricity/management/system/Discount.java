/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package electricity.management.system;

import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class Discount implements Subject{
    
    private int discount_ID;
    private String name;
    private float discount_percent;
    private String start_date;
    private String end_date;
    private Customer cust_id;
    private ArrayList<Observer> observers = new ArrayList<Observer>();
    public Discount(int discount_ID, String name, float discount_percent, String start_date, String end_date, Customer cust_id) {
        this.discount_ID = discount_ID;
        this.name = name;
        this.discount_percent = discount_percent;
        this.start_date = start_date;
        this.end_date = end_date;
        this.cust_id = cust_id;
    }

    Discount() {
    }

    public int getDiscount_ID() {
        return discount_ID;
    }

    public void setDiscount_ID(int discount_ID) {
        this.discount_ID = discount_ID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getDiscount_percent() {
        return discount_percent;
    }

    public void setDiscount_percent(float discount_percent) {
        this.discount_percent = discount_percent;
    }

    public String getStart_date() {
        return start_date;
    }

    public void setStart_date(String start_date) {
        this.start_date = start_date;
    }

    public String getEnd_date() {
        return end_date;
    }

    public void setEnd_date(String end_date) {
        this.end_date = end_date;
    }

    public Customer getCust_id() {
        return cust_id;
    }

    public void setCust_id(Customer cust_id) {
        this.cust_id = cust_id;
    }


    
    
    

    public void provide_Discount(Customer c, float discountPercent){
        DB.getInstance().addDiscount(c, discountPercent);
    }

    void revoke_Discount(Customer c, Discount d) {
        DB.removeDiscount(c,d);
    }

    
    
    @Override
    public void addObserver(Observer o) {
        observers.add(o);
    }
    
    @Override
    public void removeObserver(Observer o) {
        observers.remove(o);
    }
    
    @Override
    public void updateAll(String news) {
        for (int i = 0; i < observers.size(); i++) {
            observers.get(i).update(news);
        }
    }

    void provide_DiscountR(Residential c, float per) {
        DB.getInstance().addDiscountR(c, per);
    }

    void provide_DiscountC(Commercial c, float per) {
        DB.getInstance().addDiscountC(c, per);
    }
}
