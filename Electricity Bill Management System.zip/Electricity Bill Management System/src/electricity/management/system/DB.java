package electricity.management.system;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DB {

    private static DB DB;

  
    

    
//    private final static String userName = "root";
//    private final static String password = "";
//    private final static String dbName = "test";
    String userName;
    String password;
    String dbName;

    Connection con;

 
    
    private DB()
{
   
    userName="root";
    password = "";
    dbName = "electricity";
    
        try {
            //Loading the jdbc driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            //Get a connection to database
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + dbName, userName, password);
        } catch (Exception e) {
            System.err.println("DATABASE CONNECTION ERROR: " + e.toString());
        }
}
    
    
    
    public static DB getInstance()
{
    if (DB==null)
    {
        DB = new DB();
        
    }
    else
    {
        return DB;
    }
    return DB;
} 
    
    


    
//============================== Functions =============
    
    
    ArrayList<Residential> getAllRes() {
            ArrayList<Residential> res = new ArrayList<Residential>();
            try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from customer where type ='"+"Residential"+"'");
            Technician t = null;
            Account a = null;
            while (rs.next()) {
                res.add(new Residential(getUserByID(rs.getInt("user_id")), rs.getInt("Customer_ID"),rs.getInt("points"),t,a,rs.getInt("user_id"), getUserByID(rs.getInt("user_id")).getFirstName(), getUserByID(rs.getInt("user_id")).getLastName(),
                                getUserByID(rs.getInt("user_id")).getAddress(),getUserByID(rs.getInt("user_id")).getPhone_Number(), getUserByID(rs.getInt("user_id")).getAge(), getUserByID(rs.getInt("user_id")).getGender()));
            }
        } catch (Exception e) {
            System.err.println("DATABASE QUERY ERROR: " + e.toString());
        }
            
            return res;
    }

         ArrayList<Commercial> getAllCom() {
            ArrayList<Commercial> res = new ArrayList<Commercial>();
            try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from customer where type ='" + "Commercial" +"'");
            Technician t = null;
            Account a = null;
            while (rs.next()) {
                res.add(new Commercial(getUserByID(rs.getInt("user_id")), rs.getInt("Customer_ID"),rs.getInt("points"),t,a,rs.getInt("user_id"), getUserByID(rs.getInt("user_id")).getFirstName(), getUserByID(rs.getInt("user_id")).getLastName(),
                                getUserByID(rs.getInt("user_id")).getAddress(),getUserByID(rs.getInt("user_id")).getPhone_Number(), getUserByID(rs.getInt("user_id")).getAge(), getUserByID(rs.getInt("user_id")).getGender()));
            }
        } catch (Exception e) {
            System.err.println("DATABASE QUERY ERROR: " + e.toString());
        }
            
            return res;
    }
    
     public  DiscountEaseCompany getDiscountEaseCompany() {
        
         DiscountEaseCompany d = new DiscountEaseCompany();
        try {
        Statement stmt1 = con.createStatement();
        ResultSet rs = stmt1.executeQuery("select * from discounteasecompany where name = '" + "The Company" +"'");   

        if (rs.next()) {
            
            d.setName(rs.getString("name"));
            d.setCompanyContact_Info(rs.getString("CompanyContact_Info"));
            d.setCompany_Address(rs.getString("Company_Address"));
                return d;
        }
        rs.close();
        stmt1.close();
    } catch (Exception e) {
        System.err.println("DATABASE QUERY ERROR: " + e.toString());
        e.printStackTrace();
    }      
           return d;
    }
      
    
    
    
    
     public void addCustomer(User s,String role) 
       {
        addUser(s);   
        
         try {
            Statement stmt = con.createStatement(); 
            stmt.executeUpdate("insert into customer (user_id, customer_ID,points,tech_ID,type) values(" +s.getUser_id()+ ", '" + s.getUser_id() + "'," +0+ "," + 200 +",'"+ role + "')");
            System.out.println("Customer added");
        } catch (Exception e) {
            System.err.println("DATABASE INSERTION ERROR: " + e.toString());
        }
        
       }
       
       
       
       
       
       
       
       
    
     public void addUser(User s) {

             try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("insert into Account (username, password) values('" +s.getAccount().getUsername() + "', '" + s.getAccount().getPassword() + "')");
            System.out.println("Account added");
            stmt.executeUpdate("insert into User (username, user_id, firstName,lastName,address,phone_Number,age,gender) values('" +s.getAccount().getUsername() + "', '" + s.getUser_id() + "','" + s.getFirstName() + "','" + s.getLastName() + "','" + s.getAddress() + "','" + s.getPhone_Number() + "','" + s.getAge() + "','" + s.getGender() + "')");
            System.out.println("User added");
        } catch (Exception e) {
            System.err.println("DATABASE INSERTION ERROR: " + e.toString());
        }

    }
     
     
     
     
     
     
      public void deleteUser(User s) {
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("delete from account where username = '" + s.getAccount().getUsername() + "'");
            System.out.println("Account deleted");
            stmt.executeUpdate("delete from user where user_id = '" + s.getUser_id() + "'");
            System.out.println("User deleted");
           
        } catch (Exception e) {
            System.err.println("DATABASE DELETION ERROR: " + e.toString());
        }
    }
      
      
      
      
          public void updateUser(User s , User n) {
        try {
            
            if(notExists(s.getAccount().getUsername(), n.getAccount().getUsername())){
            Statement stmt = con.createStatement();

            stmt.executeUpdate("update user set username = '" + n.getAccount().getUsername() + "' where user_id = " + s.getUser_id());
            System.out.println("FirstName updated");
            }
        } catch (Exception e) {
            System.err.println("DATABASE UPDATE ERROR: " + e.toString());
        }
        
    }
          
          
          
          
          
          
          
          
    public User getUserByID(int id) {
    User user = null;
    try {
        Statement stmt1 = con.createStatement();
        ResultSet rs = stmt1.executeQuery("select * from user where user_id = " + id);   //user

        if (rs.next()) {
            String username = rs.getString("username");
            Statement stmt2 = con.createStatement();
            ResultSet rs1 = stmt2.executeQuery("select * from account where username = '" + username + "'");

            if (rs1.next()) {
                Account a = new Account(rs1.getString("username"), rs1.getString("password"));
                user = new User(a, rs.getInt("user_id"), rs.getString("firstName"), rs.getString("lastName"),
                                rs.getString("address"), rs.getString("phone_Number"), rs.getInt("age"), rs.getString("gender"));
            }
            rs1.close();
            stmt2.close();
        }
        rs.close();
        stmt1.close();
    } catch (Exception e) {
        System.err.println("DATABASE QUERY ERROR: " + e.toString());
        e.printStackTrace();
    }
    return user;
}
    
        Customer getCustomerByID(int id) {
        Customer c =null;
            
            try {
        Statement stmt = con.createStatement();
        ResultSet rs2 = stmt.executeQuery("select * from customer where user_id = " + id);   //user  
            
        if(rs2.next()){
            
            Statement stmt1 = con.createStatement();
            ResultSet rs = stmt1.executeQuery("select * from user where user_id = " + id);   //user

        if (rs.next()) {
            String username = rs.getString("username");
            Statement stmt2 = con.createStatement();
            ResultSet rs1 = stmt2.executeQuery("select * from account where username = '" + username + "'");

            if (rs1.next()) {
              Account a = new Account(rs1.getString("username"), rs1.getString("password"));
              User user = new User(a, rs.getInt("user_id"), rs.getString("firstName"), rs.getString("lastName"),
                                rs.getString("address"), rs.getString("phone_Number"), rs.getInt("age"), rs.getString("gender"));
              c = new Customer(user, id, rs2.getInt("points"),null, a,rs.getInt("user_id"), rs.getString("firstName"), rs.getString("lastName"),
                                rs.getString("address"), rs.getString("phone_Number"), rs.getInt("age"), rs.getString("gender"));
            
            }
            rs1.close();
            stmt2.close();
        }
        rs.close();
        stmt1.close();
        }
        rs2.close();
        stmt.close();
        } catch (Exception e) {
        System.err.println("DATABASE QUERY ERROR: " + e.toString());
        e.printStackTrace();
    }
    return c;    }
              
   
    






    
    public boolean alreadyExists(String username) {
           try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from account where username = '" + username + "'");
            
            if(rs.first()){return true;}
           
        }
           catch (Exception e) {
            System.err.println("DATABASE QUERY ERROR: " + e.toString());
             }
            return false;
    }

    
    
    
    
    public boolean notExists(String username,String uname) {
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from account where username = '" + uname + "' and username != '" + username +"'" );
            if(rs.first())
                
            {
                System.out.println("Username already Exists");
                return false;}
           
        } 
           catch (Exception e) {
            System.err.println("DATABASE QUERY ERROR: " + e.toString());
             }
        
 
            return true;
    }
    
    
    
    
    
    
    
    
    public void addDiscount(Customer c, float discountPercent) {
         try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("INSERT INTO Discount (discount_ID, name, discount_percent, start_date, end_date, cust_id) VALUES ('" + c.getCustomer_ID() + "', 'Discount', '" + discountPercent + "', '14/7', '14/8', '" + c.getCustomer_ID() + "')");
        
        Account a1 = new Account("a1","123");//Jimmy
        User s2 =new User(a1, 123, "Jimmy",  "M",  "M",  "1231241241",  123,  "M");
        Discount d = new Discount(c.getCustomer_ID(), "Discount",discountPercent , "14/7", "14/8", c);
         Company co = new Company("M","Cairo");

        Employee e = new Employee(s2,123,co,"tech", a1, 4, "M",  "M",  "M",  "012312312",  123,  "M");
        Technician t = new Technician(e,32,"3y",s2,123,co,"tech", a1, 4, "M",  "M",  "M",  "012312312",  123,  "M");
        Account a = new Account("a","123");//Sultan
        User s =new User(a, 4, "Sultan",  "M",  "M",  "012312312",  123,  "M");
        Customer cust = new Customer(s, 234,124, t,a, 32, "MO", "fghjk","fghjk", "78490439584", 23, "M");
        Commercial c1 = new Commercial(s, 234,124, t,a, 32, "MO", "fghjk","fghjk", "78490439584", 23, "M");
        Residential r1 = new Residential(s, 234,124, t,a, 32, "MO", "fghjk","fghjk", "78490439584", 23, "M");
        
        d.addObserver(r1);
        d.addObserver(c1);
        
            d.updateAll("New Message");
            
            
        } catch (Exception e) {
            System.err.println("DATABASE INSERTION ERROR: " + e.toString());
        }
    }
    
     public void addDiscountC(Customer c, float discountPercent) {
         try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("INSERT INTO Discount (discount_ID, name, discount_percent, start_date, end_date, cust_id) VALUES ('" + c.getCustomer_ID() + "', 'Discount', '" + discountPercent + "', '14/7', '14/8', '" + c.getCustomer_ID() + "')");
        
        Account a1 = new Account("a1","123");//Jimmy
        User s2 =new User(a1, 123, "Jimmy",  "M",  "M",  "1231241241",  123,  "M");
        Discount d = new Discount(c.getCustomer_ID(), "Discount",discountPercent , "14/7", "14/8", c);
         Company co = new Company("M","Cairo");

        Employee e = new Employee(s2,123,co,"tech", a1, 4, "M",  "M",  "M",  "012312312",  123,  "M");
        Technician t = new Technician(e,32,"3y",s2,123,co,"tech", a1, 4, "M",  "M",  "M",  "012312312",  123,  "M");
        Account a = new Account("a","123");//Sultan
        User s =new User(a, 4, "Sultan",  "M",  "M",  "012312312",  123,  "M");
        Customer cust = new Customer(s, 234,124, t,a, 32, "MO", "fghjk","fghjk", "78490439584", 23, "M");
        Commercial c1 = new Commercial(s, 234,124, t,a, 32, "MO", "fghjk","fghjk", "78490439584", 23, "M");
        Residential r1 = new Residential(s, 234,124, t,a, 32, "MO", "fghjk","fghjk", "78490439584", 23, "M");
        

        d.addObserver(c1);
        
            d.updateAll("New Message");
            
            
        } catch (Exception e) {
            System.err.println("DATABASE INSERTION ERROR: " + e.toString());
        }
    }
    
     public void addDiscountR(Customer c, float discountPercent) {
         try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("INSERT INTO Discount (discount_ID, name, discount_percent, start_date, end_date, cust_id) VALUES ('" + c.getCustomer_ID() + "', 'Discount', '" + discountPercent + "', '14/7', '14/8', '" + c.getCustomer_ID() + "')");
        
        Account a1 = new Account("a1","123");//Jimmy
        User s2 =new User(a1, 123, "Jimmy",  "M",  "M",  "1231241241",  123,  "M");
        Discount d = new Discount(c.getCustomer_ID(), "Discount",discountPercent , "14/7", "14/8", c);
         Company co = new Company("M","Cairo");

        Employee e = new Employee(s2,123,co,"tech", a1, 4, "M",  "M",  "M",  "012312312",  123,  "M");
        Technician t = new Technician(e,32,"3y",s2,123,co,"tech", a1, 4, "M",  "M",  "M",  "012312312",  123,  "M");
        Account a = new Account("a","123");//Sultan
        User s =new User(a, 4, "Sultan",  "M",  "M",  "012312312",  123,  "M");
        Customer cust = new Customer(s, 234,124, t,a, 32, "MO", "fghjk","fghjk", "78490439584", 23, "M");
        Commercial c1 = new Commercial(s, 234,124, t,a, 32, "MO", "fghjk","fghjk", "78490439584", 23, "M");
        Residential r1 = new Residential(s, 234,124, t,a, 32, "MO", "fghjk","fghjk", "78490439584", 23, "M");
        
        d.addObserver(r1);

        
            d.updateAll("New Message");
         
            
        } catch (Exception e) {
            System.err.println("DATABASE INSERTION ERROR: " + e.toString());
        }
    }
    
    
    

    
    
    
     
     
     
     
     
     
     
     
     
     
     //=========================
     
     public void updateMeterStatus(Customer c, boolean status) {
        try {
            Statement stmt = con.createStatement();
            String query = "UPDATE meter SET MeterStatus = " + status + " WHERE customer_ID = " + c.getCustomer_ID();
            stmt.executeUpdate(query);
            System.out.println("Meter status updated successfully");
        } catch (SQLException e) {
            System.err.println("Error updating meter status: " + e.getMessage());
        }
}
     
      public ResultSet getMeterInformation() {
        ResultSet resultSet = null;
        try {
            Statement stmt = con.createStatement();
            resultSet = stmt.executeQuery("SELECT * FROM meter");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return resultSet;
   }
     
     
     

     
         public void addBill(Bill b, Customer c) {
    try {
        Statement stmt = con.createStatement();
        // Insert the bill into the database
        String query = "INSERT INTO bill (bill_id, customer_ID, state, amount, tax_id) VALUES (" + b.getBill_Id() + ", '" + c.getCustomer_ID() + "', '" + b.getState() + "', " + b.getAmount() + ", " + b.getTax_Id() + ")";
        stmt.executeUpdate(query);
        System.out.println("Bill added successfully");
    } catch (SQLException e) {
        System.err.println("Error adding bill: " + e.getMessage());
    }
    }

      
     public boolean login(String username, String password) {
    try {
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM account WHERE username = '" + username + "' AND password = '" + password + "'");
        return rs.next(); 
    } catch (SQLException e) {
        System.err.println("invalid login: " + e.getMessage());
        return false;
    }
     }
     
     
     
      public ResultSet viewbilling() {
        ResultSet resultSet = null;
        try {
            Statement stmt = con.createStatement();

            resultSet = stmt.executeQuery("SELECT FROM bill");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return resultSet;
    }
      
        public ResultSet getCustomerInformation() {
        ResultSet resultSet = null;
        try {
            Statement stmt = con.createStatement();
            resultSet = stmt.executeQuery("SELECT * FROM customer");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return resultSet;
    }
      
    public ResultSet getbillingInformation(int customerId) {
        ResultSet rs =null;
        try {
        Statement stmt = con.createStatement();
         rs = stmt.executeQuery("SELECT * FROM bill WHERE customer_ID = " + customerId);
        
            return rs;
        
        } catch (SQLException e) {
        System.err.println("invalid login: " + e.getMessage());
       
                }
        return rs;
    }
    
    
    
 //==================================================================================
 //======Account=======
 public void updateAccountUsername(Account oldOne, Account newOne){
        
             try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("update account set username = '" + newOne.getUsername() + "' where username = '" + oldOne.getUsername()+"'");
            
        } catch (SQLException e) {
            System.err.println("Error updating username/account status: " + e.getMessage());
        }
            
            
            
        
    }
  
  
    public void updateAccountPassword(Account oldOne, Account newOne) {
        
            try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("update account set password = '" + newOne.getPassword() + "' where password = '" + oldOne.getPassword()+"'");
            
        } catch (SQLException e) {
            System.err.println("Error updating username/account status: " + e.getMessage());
        }
            
            
        
    }

    static boolean signUpEmp(User s, int emp_id, Company c, Account account, int user_id, String firstName, String lastName, String address, String phone_Number, int age, String gender, String role) {
      System.out.println("Sign up Employee"); 
        //add to database;
        return true;
    }

    
    
    
    
    
    
    
    
    
    
 //==================================================================================
    
//======Customer=======
    static void deleteCustomer(Customer c) {
    System.out.println("Deleted");     
    }

    static void updateCustomer(Customer c) {
        System.out.println("Updated");  
    }

    static void addPoints(Customer c, int i) {
        System.out.println("PointsAdded");  
    }

    static void checkPoints(Customer c) {
        System.out.println("checked");   
    }

    static void addCustomer(Customer c) {
    System.out.println("added");     
    }

    static Customer checkCustomerAvailabilty(Customer c) {
        return c;   // if found
    }
 
 //==================================================================================
 //======Employee - Accountant=======
    static void addAccountant(Accountant a) {
            System.out.println("Accountant Added successfully");
    }

    static void deleteAccountant(Accountant a) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    static void updateAccountant(Accountant a) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    static Accountant searchAcc(int id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    static void generateReports() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    static String sendWarningMessage(String s) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    
 //==================================================================================
 //======Employee - Technician======= 
    
    static void addTechnician(Technician t) {
        System.out.println("Technician Added successfully");    }

    static void deleteTechnician(Technician t) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    static void updateTechnician(Technician t) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    static Technician searchTech(int id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    static void requestTechnician(Customer c) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

 //==================================================================================
 //======Employee - Manager=======

    static void addReadMeters(Meter aThis) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    static boolean checkReadMeter(int meterId) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

 

    static void addCalcMeters(Meter aThis) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    static boolean checkCalcMeter(int meterId) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    

    static boolean checkBllID(int id) {
        return false;  
    }

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    static void addFeedback(Feedback f) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    static void deleteFeedback(Feedback f) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    static void updateFeedback(Feedback f) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    static void addPayment(Payment p) {
    }

 

    
    
    
    

    static void removeDiscount(Customer c, Discount d) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    
    static void addAppointment(Appointment a) {
       
    }
    static void removeAppointment(Appointment a) {
       
    }
    
    
    
      static Bill searchBill(int bill_id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    

    static ArrayList<Bill> viewBillingHistory(Customer c) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    static ArrayList<Bill> viewUnpaidBills(Customer c) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    
    
    
    
    
    
    
    
    //============================================================================================================





 


}