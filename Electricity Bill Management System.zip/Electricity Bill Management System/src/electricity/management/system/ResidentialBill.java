/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package electricity.management.system;

/**
 *
 * @author Dell
 */
public class ResidentialBill implements BillType {

    @Override
    public double calculateBill(double amount) {
        return amount * 1.5;
    }
}
