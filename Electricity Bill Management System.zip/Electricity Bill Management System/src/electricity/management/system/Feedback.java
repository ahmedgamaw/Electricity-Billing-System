/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package electricity.management.system;

import javax.swing.JOptionPane;

/**
 *
 * @author Dell
 */

public class Feedback {
    private int feedback_Id;
    private int rating;
    private String description;
    private Customer customer;

    public Feedback(int feedback_Id, int rating, String description, Customer customer) {
        this.feedback_Id = feedback_Id;
        this.rating = rating;
        this.description = description;
        this.customer = customer;
    }

    public Feedback(int rating, String description, Customer customer) {
        this.rating = rating;
        this.description = description;
        this.customer = customer;
    }

    public int getFeedback_Id() {
        return feedback_Id;
    }

    public void setFeedback_Id(int feedback_Id) {
        this.feedback_Id = feedback_Id;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    
    
    
    
     public void addFeedback(Feedback f){
        DB.addFeedback(f);
    }
    
    public void deleteFeedback(Feedback f){
        DB.deleteFeedback(f);
    }
    public void updateFeedback(Feedback f){
        DB.updateFeedback(f);
    }
  
    
    
    
 public void checkRating(){
        
    }
  public void confirmationMessage()
    {
        Feedbackgui f1 = new Feedbackgui();
        f1.setVisible(false); 
               
        JOptionPane.showMessageDialog(null,"Thank you for your feedback !");  
    }
    

}