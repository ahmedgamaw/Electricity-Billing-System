/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package electricity.management.system;

/**
 *
 * @author Dell
 */
public class Commercial extends Customer implements Observer {

    public Commercial(User person, int customer_ID, int points, Technician tech, Account account, int user_id, String firstName, String lastName, String address, String phone_Number, int age, String gender) {
        super(person, customer_ID, points, tech, account, user_id, firstName, lastName, address, phone_Number, age, gender);
    }
    
    
    
    @Override
    public void update(String s) {
        
        System.out.println("New Discount for Commercial");    
    }
    
    
}
