/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package electricity.management.system;

/**
 *
 * @author Dell
 */
public class Tax {
    private int tax_Id;
    private String taxDate;
    private float taxValue;

    public Tax(int tax_Id, String taxDate, float taxValue) {
        this.tax_Id = tax_Id;
        this.taxDate = taxDate;
        this.taxValue = taxValue;
    }

    public int getTax_Id() {
        return tax_Id;
    }

    public void setTax_Id(int tax_Id) {
        this.tax_Id = tax_Id;
    }

    public String getTaxDate() {
        return taxDate;
    }

    public void setTaxDate(String taxDate) {
        this.taxDate = taxDate;
    }

    public float getTaxValue() {
        return taxValue;
    }

    public void setTaxValue(float taxValue) {
        this.taxValue = taxValue;
    }
    
    public double applyTax(double d){
        
        return calculateTax(d);
    }

    private double calculateTax(double d) {
        return (((taxValue / 100 ) * d) + d);
    }
}
