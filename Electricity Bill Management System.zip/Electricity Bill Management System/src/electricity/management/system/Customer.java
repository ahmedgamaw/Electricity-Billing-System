/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package electricity.management.system;

import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class Customer extends User  {
    
    private ReadOnlyBill roi;
    private User person;
    private int customer_ID;
    private int points;
    private Technician tech;
    private String Type;

    public Customer(User person, int customer_ID, int points, Technician tech, Account account, int user_id, String firstName, String lastName, String address, String phone_Number, int age, String gender) {
        super(account, user_id, firstName, lastName, address, phone_Number, age, gender);
        this.person = person;
        this.customer_ID = customer_ID;
        this.points = points;
        this.tech = tech;
    }

    Customer() {
    }

    public String getType() {
        return Type;
    }

    public void setType(String Type) {
        this.Type = Type;
    }
    
    
    public User getPerson() {
        return person;
    }

    public void setPerson(User person) {
        this.person = person;
    }

    public int getCustomer_ID() {
        return customer_ID;
    }

    public void setCustomer_ID(int customer_ID) {
        this.customer_ID = customer_ID;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public Technician getTech() {
        return tech;
    }

    public void setTech(Technician tech) {
        this.tech = tech;
    }



    
    public void addPoints(Customer c, int i){
        DB.addPoints(c,i);
    }   
    
    public void checkPoints(Customer c){
        DB.checkPoints(c);
    } 
    
    public void addCustomer(Customer c){
        DB.addCustomer(c);
    }
    
    public void deleteCustomer(Customer c){
        DB.deleteCustomer(c);
    }
    public void updateCustomer(Customer c){
        DB.updateCustomer(c);
    }

    public Customer checkCustomerAvailabilty(Customer c){
        return DB.checkCustomerAvailabilty(c);
    }
    
    public void manageCustomerData(int i ,Customer c){
        if(i =='0'){
           deleteCustomer(c);
         }
           else if(i=='1'){
           updateCustomer(c);
         }
           else if(i=='2'){
           addCustomer(c);
           }
    }
     public void requestTechnician(Appointment a){
         tech.removeAppointment(a);
   }

    void addBill(Bill b) {
        
        
        DB.getInstance().addBill(b,this);
    }
    
    
    
     public void addFeedback(Feedback f){
        f.addFeedback(f);
    }
    
    public void deleteFeedback(Feedback f){
        f.deleteFeedback(f);
    }
    public void updateFeedback(Feedback f){
        f.updateFeedback(f);
    }
    
    
    public void makePayment(Payment p){  //type
        p.makePayment();
    }

//    void removeBill(Bill b) {
//        for (int i = 0; i < unpaidBills.size(); i++) {
//            if(b.getBill_Id()== unpaidBills.get(i).getBill_Id()){
//                unpaidBills.remove(i);
//            }
//        }
//    }

    
    
    
}
