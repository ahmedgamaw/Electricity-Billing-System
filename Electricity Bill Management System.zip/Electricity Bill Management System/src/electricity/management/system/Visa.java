/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package electricity.management.system;

import java.sql.Connection;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author Dell
 */
public class Visa implements PaymentType{
    
     
    private int cardNum;
    private String cardHolderName;
    private int cardVerificationCode;
    private String expiryDate;



    public Visa(){}
    public Visa(int cardNum, String cardHolderName, int cardVerificationCode, String expiryDate) 
    {
        this.cardNum = cardNum;
        this.cardHolderName = cardHolderName;
        this.cardVerificationCode = cardVerificationCode;
        this.expiryDate = expiryDate;

    }

    public int getCardNum() 
    {
        return cardNum;
    }

    public void setCardNum(int cardNum) 
    {
        this.cardNum = cardNum;
    }

    public String getCardHolderName() 
    {
        return cardHolderName;
    }

    public void setCardHolderName(String cardHolderName) 
    {
        this.cardHolderName = cardHolderName;
    }

    public int getCardVerificationCode() 
    {
        return cardVerificationCode;
    }

    public void setCardVerificationCode(int cardVerificationCode) 
    {
        this.cardVerificationCode = cardVerificationCode;
    }

    public String getExpiryDate() 
    {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) 
    {
        this.expiryDate = expiryDate;
    }


    @Override
    public void pay(double amount)
    {
                JOptionPane.showMessageDialog(null,"Done Successfully! $" + amount + " has been withdrawn from your Visa.");    

   
    }
   
}
