/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package electricity.management.system;

import javax.swing.JOptionPane;

/**
 *
 * @author Dell
 */
public class Appointment {
    private int id;
    private String date;
    private String time;
    private Technician t;

    public Appointment(int id, String date, String time, Technician t) {
        this.id = id;
        this.date = date;
        this.time = time;
        this.t = t;
    }

    public Appointment(int id, Technician t) {
        this.id = id;
        this.t = t;
    }
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public Technician getT() {
        return t;
    }

    public void setT(Technician t) {
        this.t = t;
    }
    

    
    public void addAppointment(){
        DB.addAppointment(this);
    }
   

     public void removeAppointment(){
        DB.removeAppointment(this);
    }
     public void confirmationMessageAdd()
    {
        AddAppointment f1 = new AddAppointment();
        f1.setVisible(false); 
               
        JOptionPane.showMessageDialog(null,"Added Successfully !");  
    }
     
     public void confirmationMessageDelete()
    {
        AddAppointment f1 = new AddAppointment();
        f1.setVisible(false); 
               
        JOptionPane.showMessageDialog(null,"Deleted Successfully !");  
    }
}

