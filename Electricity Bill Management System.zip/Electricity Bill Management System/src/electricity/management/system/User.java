/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package electricity.management.system;

/**
 *
 * @author Dell
 */
public class User {
    
    private Account account;
    
    private int user_id;
    private String firstName;
    private String lastName;
    private String address;    
    private String phone_Number;
    private int age;
    private String gender;

    public User(Account account, int user_id, String firstName, String lastName, String address, String phone_Number, int age, String gender) {
        this.account = account;
        this.user_id = user_id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
        this.phone_Number = phone_Number;
        this.age = age;
        this.gender = gender;
    }

    User() {
    }

    public Account getAccount() {
        return account;
    }

    public void setAccount(Account account) {
        this.account = account;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone_Number() {
        return phone_Number;
    }

    public void setPhone_Number(String phone_Number) {
        this.phone_Number = phone_Number;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    
    
    
    
    
    
    //Acts as a contoller 
    
    public void login(String username, String pass) {
         account.login(username,pass);
   }
    
    public void signUp(User s,String role) {
         account.signUp(s,role);
   }
    
    
    public boolean signUpEmpTech(int emp_id,Company c,String role,String exp) {
       
        return account.signUpEmpTech(this,emp_id, c,this.getAccount(),role,exp);
   }
    public boolean signUpEmpAcc(int emp_id,Company c,String role,String CV) {
       
        return account.signUpEmpAcc(this,emp_id, c,role,CV);
   }
    
    
    
    
}
