/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package electricity.management.system;

import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class Employee extends User {
    private User person;
    
    
    private int employee_ID;
    private Company company;
    private String role;

    public Employee(User person, int employee_ID, Company company, String role, Account account, int user_id, String firstName, String lastName, String address, String  phone_Number, int age, String gender) {
        super(account, user_id, firstName, lastName, address, phone_Number, age, gender);
        this.person = person;
        this.employee_ID = employee_ID;
        this.company = company;
        this.role = role;
    }

    public User getPerson() {
        return person;
    }

    public void setPerson(User person) {
        this.person = person;
    }

    public int getEmployee_ID() {
        return employee_ID;
    }

    public void setEmployee_ID(int employee_ID) {
        this.employee_ID = employee_ID;
    }

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

  
    

    
    
   
    
    
}
