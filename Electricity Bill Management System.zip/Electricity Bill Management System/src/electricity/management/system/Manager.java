/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package electricity.management.system;

import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class Manager extends Employee {
    
    private static Manager manager ;
    
    private int manager_ID;
    
    private ArrayList<Technician>employerTech = new ArrayList<Technician>();
    private ArrayList<Accountant>employerAcc = new ArrayList<Accountant>();

    public Manager(int manager_ID, User person, int employee_ID, Company company, String role, Account account, int user_id, String firstName, String lastName, String address, String phone_Number, int age, String gender) {
        super(person, employee_ID, company, role, account, user_id, firstName, lastName, address, phone_Number, age, gender);
        this.manager_ID = manager_ID;
    }

    

    
    
    
    
    
    public static Manager getManager() {
        if(manager==null){
            Account a = new Account("Newton","apple");
            Company c = new Company("فاتورتك", "Cairo");
            User s =new User(a, 1, "Magnus",  "Carlsen",  "Maadi",  "01005000500",  123,  "M");
            
            Employee e = new Employee(s, 1,c, "Manager",a,s.getUser_id(),s.getFirstName(),s.getLastName(),s.getAddress(),s.getPhone_Number(),s.getAge(),s.getGender());
            Manager m = new Manager(1,s, 1,c, "Manager",a,s.getUser_id(),s.getFirstName(),s.getLastName(),s.getAddress(),s.getPhone_Number(),s.getAge(),s.getGender());
            manager=m;
            return manager;
        }
        else{
            return manager;
        }
    }

    
    
    
    public static void setManager(Manager manager) {
        Manager.manager = manager;
    }

    public int getManager_ID() {
        return manager_ID;
    }

    public void setManager_ID(int manager_ID) {
        this.manager_ID = manager_ID;
    }

    public ArrayList<Technician> getEmployerTech() {
        return employerTech;
    }

    public void setEmployerTech(ArrayList<Technician> employerTech) {
        this.employerTech = employerTech;
    }

    public ArrayList<Accountant> getEmployerAcc() {
        return employerAcc;
    }

    public void setEmployerAcc(ArrayList<Accountant> employerAcc) {
        this.employerAcc = employerAcc;
    }

  

    

   



    

    

    
    public void applyForJobTech(int emp_ID){
    
        for (int i = 0; i < employerTech.size(); i++) {
            
            if(employerTech.get(i).getEmployee_ID()==emp_ID){
                
            DB.addTechnician(employerTech.get(i));
            }
            
        }
        
    }
    
    public void applyForJobAcc(int emp_ID){
    
        for (int i = 0; i < employerAcc.size(); i++) {
            
            if(employerAcc.get(i).getEmployee_ID()==emp_ID){
                
            DB.addAccountant(employerAcc.get(i));
            }
            
            
        }
        
    }
    
     public void addEmployerA(Accountant e){
        
        employerAcc.add(e);
    }

    public  void addEmployerT(Technician t) {
        employerTech.add(t);
    }
    
    
    public Accountant checkEmployerAccData(int emp_ID){
    
        for (int i = 0; i < employerAcc.size(); i++) {
            
            if(employerAcc.get(i).getEmployee_ID()==emp_ID){
                
            return employerAcc.get(i);
            } 
            
        }
        
        return null;
    }
    
    public Technician checkEmployerTechData(int emp_ID){
    
        for (int i = 0; i < employerTech.size(); i++) {
            
            if(employerTech.get(i).getEmployee_ID()==emp_ID){
                
            return employerTech.get(i);
            } 
            
        }
        
        return null;
    }
    
    
    

    
    
    
}
