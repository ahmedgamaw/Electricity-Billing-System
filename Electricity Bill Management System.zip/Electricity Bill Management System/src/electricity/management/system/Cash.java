/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package electricity.management.system;

import javax.swing.JOptionPane;

/**
 *
 * @author Dell
 */
public class Cash implements PaymentType{
    
    @Override
    public void pay(double amount)
    {
        PaymentMethod m1 = new PaymentMethod();
        m1.setVisible(false);        
        JOptionPane.showMessageDialog(null,"Done Successfully! Please pay $" + amount + " on arrival.");    
    }
}
