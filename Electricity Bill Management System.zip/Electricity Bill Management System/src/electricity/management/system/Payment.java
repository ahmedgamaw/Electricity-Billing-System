/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package electricity.management.system;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Dell
 */public class Payment {
 
    private int paymentId;
    private String paymentDate;
    private Bill bill;
    private Customer c;
    private int paymentLimit;
    
    private PaymentType payment;
    

public Payment(){}
    public Payment(int paymentId, String paymentDate, Bill bill, Customer c, int paymentLimit, PaymentType payment) {
        this.paymentId = paymentId;
        this.paymentDate = paymentDate;
        this.bill = bill;
        this.c = c;
        this.paymentLimit = paymentLimit;
        this.payment = payment;
    }

    public Payment(int paymentId, String paymentDate, int paymentLimit) {
        this.paymentId = paymentId;
        this.paymentDate = paymentDate;
        this.paymentLimit = paymentLimit;
        
    }

    

    public int getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(int paymentId) {
        this.paymentId = paymentId;
    }

    public String getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(String paymentDate) {
        this.paymentDate = paymentDate;
    }

    public Bill getBill() {
        return bill;
    }

    public void setBill(Bill bill) {
        this.bill = bill;
    }

    public Customer getC() {
        return c;
    }

    public void setC(Customer c) {
        this.c = c;
    }

    public int getPaymentLimit() {
        return paymentLimit;
    }

    public void setPaymentLimit(int paymentLimit) {
        this.paymentLimit = paymentLimit;
    }

    public PaymentType getPayment() {
        return payment;
    }

    public void setPayment(PaymentType payment) {
        this.payment = payment;
    }
    
 
    public void confirmationMessage()
    {
        PayWithVisa m1 = new PayWithVisa();
        m1.setVisible(false); 
               
        JOptionPane.showMessageDialog(null,"Successful Payment !");  
    }
    
    

  
    
    

    void makePayment() {
        //change bill state
        //bill.getCustomer().removeBill(bill);
        //remove the bill from the Database of the unpaid Bills (first remove the ArrayList in Customer)
        
       
        DB.addPayment(this);
    }
}