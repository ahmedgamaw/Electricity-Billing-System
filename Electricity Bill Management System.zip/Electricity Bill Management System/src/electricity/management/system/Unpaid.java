/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package electricity.management.system;

/**
 *
 * @author Dell
 */
public class Unpaid implements BillState{

    @Override
    public void updateState(Bill b) {
            BillState nb = new Pending();
            b.setBs(nb);
            System.out.println("Unpaid");
    }
    
}
