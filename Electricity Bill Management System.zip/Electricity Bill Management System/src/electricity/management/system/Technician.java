/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package electricity.management.system;

import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class Technician extends Employee {

    private Employee e;
    private int tech_id;
    private String experiance;

    public Technician(Employee e, int tech_id, String experiance, User person, int employee_ID, Company company, String role, Account account, int user_id, String firstName, String lastName, String address, String phone_Number, int age, String gender) {
        super(person, employee_ID, company, role, account, user_id, firstName, lastName, address, phone_Number, age, gender);
        this.e = e;
        this.tech_id = tech_id;
        this.experiance = experiance;
    }

    



    public Employee getE() {
        return e;
    }

    public void setE(Employee e) {
        this.e = e;
    }

    public int getTech_id() {
        return tech_id;
    }

    public void setTech_id(int tech_id) {
        this.tech_id = tech_id;
    }

    public String getExperiance() {
        return experiance;
    }

    public void setExperiance(String experiance) {
        this.experiance = experiance;
    }


    
    

    //Methods:
    
    
    
    
     public void addTechnician(Technician t){
        DB.addTechnician(t);
    }
    
    public void deleteTechnician(Technician t){
        DB.deleteTechnician(t);
    }
    public void updateTechnician(Technician t){
        DB.updateTechnician(t);
    }
  
    
   public Technician search(int id){
        return DB.searchTech(id);
   }
  
   
   public void requestTechnician(Appointment a){
         a.removeAppointment();
   }
  
    public void readMeter(Meter m){
         m.readMeter();
   }
   
    
    
    public void addAppointment(Appointment a){
        a.addAppointment();
    }
    
     public void removeAppointment(Appointment a){
        a.removeAppointment();
    }
    
   

}
