/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package electricity.management.system;

import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class DiscountEaseCompany {
    private String name;
    private String CompanyContact_Info;
    private String Company_Address;

    public DiscountEaseCompany(String name, String CompanyContact_Info, String Company_Address) {
        this.name = name;
        this.CompanyContact_Info = CompanyContact_Info;
        this.Company_Address = Company_Address;
    }

    public DiscountEaseCompany() {
        
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCompanyContact_Info() {
        return CompanyContact_Info;
    }

    public void setCompanyContact_Info(String CompanyContact_Info) {
        this.CompanyContact_Info = CompanyContact_Info;
    }

    public String getCompany_Address() {
        return Company_Address;
    }

    public void setCompany_Address(String Company_Address) {
        this.Company_Address = Company_Address;
    }



    
    public void provide_Discount(Customer c, float discountPercent){
        Discount d = new Discount ();
        d.provide_Discount(c, discountPercent);
    }
    
    public void revoke_Discount(Discount d,Customer c){
        d.revoke_Discount(c,d);
    }

    ArrayList<Residential> getAllRes() {
        
        return DB.getInstance().getAllRes();
    }

    ArrayList<Commercial> getAllCom() {
        return DB.getInstance().getAllCom();  
    }

    void provide_DiscountR(Residential c, float per) {
    Discount d = new Discount ();
        d.provide_DiscountR(c, per);    }

    void provide_DiscountC(Commercial c, float per) {
         Discount d = new Discount ();
        d.provide_DiscountC(c, per);    }
    
}
