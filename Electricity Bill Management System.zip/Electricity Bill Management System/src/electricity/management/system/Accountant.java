/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package electricity.management.system;

import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class Accountant extends Employee {

  private Employee e;
  private int acc_id;
  private String cv;

    public Accountant(Employee e, int acc_id, String cv, User person, int employee_ID, Company company, String role, Account account, int user_id, String firstName, String lastName, String address, String phone_Number, int age, String gender) {
        super(person, employee_ID, company, role, account, user_id, firstName, lastName, address, phone_Number, age, gender);
        this.e = e;
        this.acc_id = acc_id;
        this.cv = cv;
    }

    public Employee getE() {
        return e;
    }

    public void setE(Employee e) {
        this.e = e;
    }

    public int getAcc_id() {
        return acc_id;
    }

    public void setAcc_id(int acc_id) {
        this.acc_id = acc_id;
    }

    public String getCv() {
        return cv;
    }

    public void setCv(String cv) {
        this.cv = cv;
    }


    

   

   
  
  
  //Methods:
  
  
  public void addAccountant(Accountant a){
        DB.addAccountant(a);
    }
    
    public void deleteAccountant(Accountant a){
        DB.deleteAccountant(a);
    }
    public void updateAccountant(Accountant a){
        DB.updateAccountant(a);
    }
  
    
    
    
   public Accountant search(int id){
        return DB.searchAcc(id);
   }
  
   public void generateReports(){
         DB.generateReports();
   }
  
   public String sendWarningMessage(String s){
   
   return DB.sendWarningMessage(s);
   }
   
   
   ///========================
   
   
   
   
   public void calculatMeter(Meter m){
    if(checkRM(m.getMeterId())){
    
        m.calculateMeter();
    
    }       
   }

    public boolean checkRM(int meterId) {
        return DB.checkReadMeter(meterId);
    }
    
    public boolean checkCalcM(int meterId) {
        return DB.checkCalcMeter(meterId);
    }
    
    
  
 
    // This method creates a Bill instance with the calculated charges
    public void createBillForCustomer(int B_id,double amount,Tax t) {
        Bill b=new Bill();
        
        double baseAmount = b.calculateBill(amount);
        
        b.addBill(B_id, amount, t ,baseAmount);    
    }

    
    
}
