/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package electricity.management.system;

/**
 *
 * @author Dell
 */
public class Meter {
   
  
  private int meter_id;
  
  private double reading;
  
  private boolean meterReadStatus;
  
  private boolean meterCalcStatus;
  
  private boolean meterStatus;
 
  private Customer customer;
  
  private ElectricityState es;

   

    public Meter(int meter_id, double reading, boolean meterReadStatus, boolean meterCalcStatus, boolean meterStatus, Customer customer) {
        this.meter_id = meter_id;
        this.reading = reading;
        this.meterReadStatus = meterReadStatus;
        this.meterCalcStatus = meterCalcStatus;
        this.meterStatus = meterStatus;
        this.customer = customer;
        es = new Connected();
    }

    public int getMeter_id() {
        return meter_id;
    }

    public void setMeter_id(int meter_id) {
        this.meter_id = meter_id;
    }

    public ElectricityState getEs() {
        return es;
    }

    public void setEs(ElectricityState es) {
        this.es = es;
    }
  
  
    public void  updateState(){
    es.updateState(this);
    }
    
    
    
    
    
    
    
    

   
   
   public boolean getMeterStatus() {
    return meterStatus;
  }

  public int getMeterId() {
    return meter_id;
  }

  public double getReading() {
    return reading;
  }


  public Customer getCustomer() {
    return customer;
  }

  // Setters


  public void setMeterId(int meter_id) {
    this.meter_id = meter_id;
  }

  public void setReading(double reading) {
    this.reading = reading;
  }

  public void setMeterReadStatus(boolean meterReadStatus) {
    this.meterReadStatus = meterReadStatus;
  }

  public void setMeterCalcStatus(boolean meterCalcStatus) {
    this.meterCalcStatus = meterCalcStatus;
  }

  public void setMeterStatus(boolean meterStatus) {
    this.meterStatus = meterStatus;
  }

  public void setCustomer(Customer customer) {
    this.customer = customer;
  }

  
  
  //=========================
  
  public boolean isRead() {
    return meterReadStatus;
  }

  public boolean isMeterCalcStatus() {
    return meterCalcStatus;
  }

  public boolean isMeterStatus() {
    return meterStatus;
  }
  
  public boolean isMeterReadStatus() {
        return meterReadStatus;
    }
  
  public void readMeter() {
    meterReadStatus = true;
    DB.addReadMeters(this);
  }
  
   public void calculateMeter() {
    meterCalcStatus=true;
    reading *=2;
    DB.addCalcMeters(this);
    
  }
   
  
}
