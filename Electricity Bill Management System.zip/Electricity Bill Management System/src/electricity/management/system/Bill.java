/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package electricity.management.system;

import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class Bill {

    private int bill_Id;
    private String state;
    private double amount;
    private int tax_Id;
    private Customer customer;
    private BillType b;
    private BillState bs;

    public Bill(int bill_Id, String state, double amount, int tax_Id, Customer customer, BillType b, BillState bs) {
        this.bill_Id = bill_Id;
        this.state = state;
        this.amount = amount;
        this.tax_Id = tax_Id;
        this.customer = customer;
        this.b = b;
        this.bs = bs;
         b=  new  ResidentialBill();
         bs = new Unpaid();
    }
    
    
    Bill() {
    }

    Bill(int billId, String state, double amount, int taxId, Customer c, Object object, Object object0) {
    }

    public BillState getBs() {
        return bs;
    }

    public void setBs(BillState bs) {
        this.bs = bs;
    }

    public int getTax_Id() {
        return tax_Id;
    }

    public void setTax_Id(int tax) {
        this.tax_Id = tax;
    }

    
    public int getBill_Id() {
        return bill_Id;
    }

    public void setBill_Id(int bill_Id) {
        this.bill_Id = bill_Id;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    
    
    
    
    //for ROI
    
    public Bill getBill(int bill_id){
        return DB.searchBill(bill_id);
    }
    
    
    public ArrayList<Bill> viewBillingHistory(Customer c){
    
    return DB.viewBillingHistory(c);
    }
    
   
    
    
    
    
    
    
    
    
    
    
    public double calculateBill(double amount) {
        
        return b.calculateBill(amount);
    }
    
    
    
    
    private boolean checkBillID(int B_id) {
        return DB.checkBllID(B_id);   
    
    }
    
    public boolean addBill(int B_id,double amount,Tax t,double baseAmount){
        if(checkBillID(B_id) == false){
        // Calculate base charge for the meter reading
        

        // Calculate the total amount with tax
        double totalAmount = t.applyTax(baseAmount);

        // Create a new Bill object with the total amount
        //Bill b = new Bill(B_id,totalAmount,meter.getCustomer());

        // Add the new Bill to the customer's unpaid bills
        
        
        //meter.getCustomer().addBill(b);

        // Return the created bill
        return true;
        }
        else{
            return false;
        }
    }
    
//    public boolean countBill(Meter meter){
//        if(meter.getCustomer().getUnpaidBills().size()>=3 && meter.getMeterStatus()==true){
//        meter.setMeterStatus(false);
//        return true;
//        }
//        else{
//            return false;
//        }
//    }

  
    
    //State
    
    
    public void  updateState(){
    bs.updateState(this);
    }
    
    
}
