/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package electricity.management.system;

import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class Account {
    private String username;
    private String password;


    public Account(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public Account() {
    }

    
    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
    
    
  //Methods:
    
    
    
   public void login(String username, String pass) {
         DB.getInstance().login(username,pass);
   }
   
   
   public void signUp(User s,String role) {

        DB.getInstance().addCustomer(s,role);
        
    }
   
    public boolean signUpEmpTech( User s, int emp_id, Company c, Account account, String role, String experience) {
       Account a1= new Account(username,password);
       
       if(a1.alreadyExists(username) == false){
        
//           Employee e = new Employee(s,emp_id, c,s.getAccount(),s.getUser_id(),s.getFirstName(), s.getLastName(), s.getAddress(), s.getPhone_Number(), s.getAge(), s.getGender(),role);
//           
//           Technician t = new Technician(s,emp_id, c,s.getAccount(),s.getUser_id(),s.getFirstName(), s.getLastName(), s.getAddress(), s.getPhone_Number(), s.getAge(), s.getGender(),role,experience);
//           
//           Manager.getManagerInstance().addEmployerT(t);
    
           
           return DB.signUpEmp(s,emp_id, c,s.getAccount(),s.getUser_id(),s.getFirstName(), s.getLastName(), s.getAddress(), s.getPhone_Number(), s.getAge(), s.getGender(),role);
   }
       else {
       return false;
       }
   }
    
    
    
    
    public boolean signUpEmpAcc( User s, int emp_id, Company c, String role, String CV) {
      
       
       if(alreadyExists(username) == false){
        
//           Employee e = new Employee(s,emp_id, c,s.getAccount(),s.getUser_id(),s.getFirstName(), s.getLastName(), s.getAddress(), s.getPhone_Number(), s.getAge(), s.getGender(),role);
//           
//           Accountant a = new Accountant(s,emp_id, c,s.getAccount(),s.getUser_id(),s.getFirstName(), s.getLastName(), s.getAddress(), s.getPhone_Number(), s.getAge(), s.getGender(),role,CV);
//           
//           Manager.getManagerInstance().addEmployerA(a);
           
           
           
           return DB.signUpEmp(s,emp_id, c,s.getAccount(),s.getUser_id(),s.getFirstName(), s.getLastName(), s.getAddress(), s.getPhone_Number(), s.getAge(), s.getGender(),role);
   }
       else {
       return false;
       }
   }
    
    
    
  public boolean alreadyExists( String username) {
        
      return DB.getInstance().alreadyExists(username);
    }
  
  
  public boolean notExists( String username, String uname) {

     return DB.getInstance().notExists(username,uname);
  }
  
}
