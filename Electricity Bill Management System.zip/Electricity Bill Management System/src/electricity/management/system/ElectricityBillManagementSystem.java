/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package electricity.management.system;

/**
 *
 * @author Dell
 */
public class ElectricityBillManagementSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Account a = new Account("a","123");//Sultan
        Account a1 = new Account("a1","123");//Jimmy       
        Account a2 = new Account("a3","123");//


        
        Company c = new Company("M","Cairo");
        

        User s =new User(a, 4, "Sultan",  "M",  "M",  "012312312",  123,  "M");
        User s2 =new User(a1, 123, "Jimmy",  "M",  "M",  "1231241241",  123,  "M");
        
        User s3 =new User(a2, 125, "Moaz",  "M",  "M",  "1231241241",  123,  "M");
        Employee e = new Employee(s2,123,c,"tech", a1, 4, "M",  "M",  "M",  "012312312",  123,  "M");
        Employee e1 = new Employee(s3,142,c,"acc", a1, 4, "M",  "M",  "M",  "012312312",  123,  "M");
        
        Technician t = new Technician(e,32,"3y",s2,123,c,"tech", a1, 4, "M",  "M",  "M",  "012312312",  123,  "M");
        Accountant acc = new Accountant(e1,32,"good",s2,123,c,"tech", a1, 4, "M",  "M",  "M",  "012312312",  123,  "M");
        
        
        Customer cust = new Customer(s, 234,124, t,a, 32, "MO", "fghjk","fghjk", "78490439584", 23, "M");
         
        Commercial c1 = new Commercial(s, 234,124, t,a, 32, "MO", "fghjk","fghjk", "78490439584", 23, "M");
        Residential r1 = new Residential(s, 234,124, t,a, 32, "MO", "fghjk","fghjk", "78490439584", 23, "M");
        
        Meter m = new Meter(2, 2.0,true,true,true, cust) ;

        Bill b = new Bill(124, "Paid", 2, 6,cust,null,null);        
                
        
        Discount d1 = new Discount(123, "asd", 4.4f,"asd", "asd",c1);
        


        
        DB.getInstance().updateUser(s2, s3);
//
//        if( DB.getInstance().alreadyExists("a2")){
//            System.out.println("User Already Exists");
//        }
//        else{
//            DB.getInstance().addUser(s3);
//
//        }
//                
//  
//        
//        
//        DB.getInstance().updateUser(s, s3);
//        DB.getInstance().updateUser(s2, s3);
//
//        DB.getInstance().deleteUser(s);
//        
//        
//
//        
//       //Meter State Pattern
//        
//        m.updateState();
//        m.updateState();
//        m.updateState();
//        m.updateState();
//        m.updateState();
//        m.updateState();
//        
//        
//        //Bill State Pattern
//        b.updateState();
//        b.updateState();
//        b.updateState();
//        
//        c1.makePayment(p);
//        
//        
//        
//        //Observer Pattern
//        d1.addObserver(r1);
//        d1.addObserver(c1);  
//        d1.updateAll("NEW NEWS");
//        
//        
//        
//        
//        System.out.println(b.calculateBill(m));
          
        
        
        }       
}
                
                
                
//        Customer cu =new Customer(a, 123, "M",  "M",  "M",  123,  123,  "M");
//       
//        s.signUpEmpAcc(13, c, "Acc", "3 Years");
//       
//        Manager.getManagerInstance().applyForJobAcc(13);
//        
//        Accountant acc = new Accountant(s,1,c,a,123, "M",  "M",  "M",  123,  123,  "M","Acc", "3 Years");
//        Meter m= new Meter(1, 2.4, true, true, true, cu);
//        Tax t=new Tax(1,"M",1.4f);
//        
        
        
        
        
        
//        acc.createBillForCustomer(123, m, t);
        
        
        

